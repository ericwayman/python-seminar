from distutils.core import setup

setup(name='CalCalc',
	version='1.0',
	description='CalCalc module',
	author='Eric Wayman',
	author_email='ewayman@gmail.com',
	py_modules=['CalCalc'],
	)